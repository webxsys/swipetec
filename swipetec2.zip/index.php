<!DOCTYPE html>
<html lang="en">

  <?php include_once 'head.php'; ?>

  <body>
  
  <!-- BEGAIN PRELOADER -->
  <div id="preloader">
    <div id="status">&nbsp;</div>
  </div>
  <!-- END PRELOADER -->

  <!-- SCROLL TOP BUTTON -->
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
  <!-- END SCROLL TOP BUTTON -->

  <!-- Start header -->
  <?php include_once 'header.php'; ?>
  <!-- End header -->
  
  <!-- Start login modal window -->
  <?php //include_once 'login_modal.php'; ?>
  <!-- End login modal window -->

  <!-- BEGIN MENU -->
  <section id="menu-area">
      <nav class="navbar navbar-default  navbar-fixed-top " role="navigation">
          <div class="container">
              <div class="navbar-header">
                  <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <!-- LOGO -->
                  <!-- TEXT BASED LOGO -->
                  <!-- a class="navbar-brand" href="index.html">Intensely</a -->
                  <!-- IMG BASED LOGO  -->
                  <a class="navbar-brand" href="index.php"><img src="assets/images/logo.png" alt="SWIPETEC" title="SWIPETEC"></a>
              </div>
              <div id="navbar" class="navbar-collapse collapse">
                  <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                      <li class="active"><a href="index.php">Home</a></li>
                      <li><a href="internet.php">Internet</a></li>
                      <li><a href="retail.php">Retail</a></li>
                      <li><a href="about.php">About</a></li>
                      <li><a href="solutions.php" >Solutions </a></li>
                      <li><a href="partners.php">Partners</a></li>
                      <li><a href="contact.php">Contact</a></li>
                  </ul>
              </div><!--/.nav-collapse -->
              <a href="#" id="search-icon">
                  &nbsp;&nbsp;<i class="fa fa-search">
                  </i>
              </a>
          </div>
      </nav>
  </section>
  <!-- END MENU --> 

  <!-- Start slider -->
  <section id="slider">
    <div class="main-slider">
      <div class="single-slide">
        <img src="assets/images/slider-1.jpg" alt="img">
        <div class="slide-content">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-sm-6">
                <div class="slide-article">
                  <h1 class="animated fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">Most Trusted Merchant Partner</h1>
                  <p class="animated fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.75s">Find out why Swipetec stands out from all other credit card processing service providers.</p>
                  <a class="read-more-btn wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" href="#">Learn More</a>
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="slider-img wow fadeInUp">
<!--                  <img src="assets/images/person1.png" alt="business man">
-->                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="single-slide">
        <img src="assets/images/slider-3.jpg" alt="img">
        <div class="slide-content">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-sm-6">
                <div class="slide-article-2">
                  <h1 class="animated fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">FAST APPROVAL</h1>
                  <p class="animated fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.75s">Start accepting credit cards today ! No application fees.</p><br>
                  <a class="read-more-btn animated fadeInUp" data-wow-duration="1s" data-wow-delay="1s" href="#">Get Started</a>
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="slider-img wow fadeInUp">
                  <!--<img src="assets/images/person2.png" alt="business man">-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>          
    </div>
  </section>
  <!-- End slider -->
  <div style="text-align:center;"><a class="purchase-btn" href="#">Get Started Now</a></div>
  <section id="portfolio">
    <div class="portfolio-area">
       <div class="col-md-12">
          <div class="title-area">
            <h2 class="title wow fadeInUp"><span>Payment Transaction Solutions</span></h2>
            <span class="line wow fadeInUp"></span>
            <p  class="wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">Channels for any way your customers pay.</p>
          </div>
        </div>
       <!-- portfolio menu -->
       <!--<div class="portfolio-menu">
         <ul>
           <li class="filter" data-filter="all">All</li>
           <li class="filter" data-filter=".branding">Branding</li>
           <li class="filter" data-filter=".design">Design</li>
           <li class="filter" data-filter=".development">Development</li>
           <li class="filter" data-filter=".photography">Photography</li>
         </ul>
       </div>-->      
       <!-- Portfolio container -->
       <div id="mixit-container" class="portfolio-container">
         <div class="single-portfolio mix">
           <div class="single-item">
             <img src="assets/images/shopping.jpg" alt="img">
             <div class="single-item-content">               
                <a class="fancybox view-icon" href="retail.php"><i class="fa fa-leaf"></i></a>
                <div class="portfolio-title">
                    <a class="view-icon" href="retail.php"><h4> RETAIL</h4></a>
                  <span></span>
                </div>
             </div>
           </div>
         </div>
         <div class="single-portfolio mix">
           <div class="single-item">
             <img src="assets/images/restaurant.jpg" alt="img">
            <div class="single-item-content">               
              <a class="fancybox view-icon"  href="restaurant.php"><i class="fa fa-bank"></i></a>
              <div class="portfolio-title">
                <a class="view-icon" href="restaurant.php"><h4>RESTAURANT</h4></a>
                <span></span>
              </div>
             </div>
           </div>
         </div>
         <div class="single-portfolio mix">
           <div class="single-item">
             <img src="assets/images/ecommerce-payment-processing.jpg" alt="img">
             <div class="single-item-content">               
                <a class="fancybox view-icon" data-fancybox-group="gallery" href="ecommerce.php"><i class="fa fa-thumbs-o-up"></i></a>
                <div class="portfolio-title">
                  <a class="view-icon" href="ecommerce.php"><h4>E-COMMERCE</h4></a>
                  <span></span>
                </div>
             </div>
           </div>
         </div>
         <div class="single-portfolio mix">
           <div class="single-item">
             <img src="assets/images/mailorder.jpg" alt="img">
             <div class="single-item-content">               
                <a class="fancybox view-icon" data-fancybox-group="gallery" href="mailorder.php"><i class="fa fa-envelope"></i></a>
                <div class="portfolio-title">
                    <a class="view-icon" href="mailorder.php"><h4>MAIL ORDER</h4></a>
                    <span>TELEPHONE ORDER</span>
                </div>
             </div>
           </div>
         </div>
         <div class="single-portfolio mix">
               <div class="single-item">
                   <img src="assets/images/CHECK.jpg" alt="img">
                   <div class="single-item-content">
                       <a class="fancybox view-icon" href="retail.php"><i class="fa fa-leaf"></i></a>
                       <div class="portfolio-title">
                           <a class="view-icon" href="retail.php"><h4> RETAIL</h4></a>
                           <span></span>
                       </div>
                   </div>
               </div>
           </div>
         <div class="single-portfolio mix">
               <div class="single-item">
                   <img src="assets/images/gift.jpg" alt="img">
                   <div class="single-item-content">
                       <a class="fancybox view-icon" data-fancybox-group="gallery" href="assets/images/gift.jpg"><i class="fa fa-search-plus"></i></a>
                       <div class="portfolio-title">
                           <h4>GIFT & LOYALTY CARDS</h4>
                           <span></span>
                       </div>
                   </div>
               </div>
           </div>
         <div class="single-portfolio mix">
               <div class="single-item">
                   <img src="assets/images/cashadvance.jpg" alt="img">
                   <div class="single-item-content">
                       <a class="fancybox view-icon" data-fancybox-group="gallery" href="ecommerce.php"><i class="fa fa-thumbs-o-up"></i></a>
                       <div class="portfolio-title">
                           <a class="view-icon" href="ecommerce.php"><h4>E-COMMERCE</h4></a>
                           <span></span>
                       </div>
                   </div>
               </div>
           </div>
         <div class="single-portfolio mix">
               <div class="single-item">
                   <img src="assets/images/smartphone.jpg" alt="img">
                   <div class="single-item-content">
                       <a class="fancybox view-icon" data-fancybox-group="gallery" href="mailorder.php"><i class="fa fa-envelope"></i></a>
                       <div class="portfolio-title">
                           <a class="view-icon" href="mailorder.php"><h4>MAIL ORDER</h4></a>
                           <span>TELEPHONE ORDER</span>
                       </div>
                   </div>
               </div>
           </div>
       </div>
    </div>
  </section>
  <!-- End portfolio -->
  <!-- Start Feature -->


  <!-- Start Testimonial section -->
  <section id="testimonial">
      <div class="container">
          <div class="row">
              <div class="col-md-6">
                  <div class="row">
                      <div class="col-md-12">
                          <div class="title-area">
                              <h2 class="title">Our Clients Say</h2>
                              <span class="line"></span>
                          </div>
                      </div>
                      <div class="col-md-12">
                          <!-- Start testimonial slider -->
                          <div class="testimonial-slider">
                              <!-- Start single slider -->
                              <div class="single-slider">
                                  <div class="testimonial-img">
                                      <img src="assets/images/testi1.jpg" alt="testimonial image">
                                  </div>
                                  <div class="testimonial-content">
                                      <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                      <h6>Zeke Unger, <span>CEO</span></h6>
                                  </div>
                              </div>
                              <!-- Start single slider -->
                              <div class="single-slider">
                                  <div class="testimonial-img">
                                      <img src="assets/images/testi2.jpg" alt="testimonial image">
                                  </div>
                                  <div class="testimonial-content">
                                      <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                      <h6>David Burney, <span>Sr. Ecommerce Developer</span></h6>
                                  </div>
                              </div>
                              <!-- Start single slider -->
<!--                              <div class="single-slider">
                                  <div class="testimonial-img">
                                      <img src="assets/images/testi2.jpg" alt="testimonial image">
                                  </div>
                                  <div class="testimonial-content">
                                      <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                      <h6>Michel, <span>Developer</span></h6>
                                  </div>
                              </div>
-->                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-md-6"></div>
          </div>
      </div>
  </section>
  <!-- End Testimonial section -->
  <!-- Start latest news -->
  <section id="latest-news">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="title-area">
                      <h2 class="title">Start Now</h2>
                      <span class="line"></span>
                      <p></p>
                  </div>
              </div>
              <div class="col-md-12">
                  <div class="latest-news-content">
                      <div class="row">
                          <!-- start single latest news -->
                          <div class="col-md-4">
                              <article class="blog-news-single">
                                  <div class="blog-news-img">
                                      <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-1.jpg" alt="image"></a>
                                  </div>
                                  <div class="blog-news-title">
                                      <h2><a href="blog-single-with-right-sidebar.html">Swipetec Rapid Quote</a></h2>
                                      <!--                                      <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>-->
                                  </div>
                                  <!-- <div class="blog-news-details">
                                       <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                       <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                                   </div>-->
                              </article>
                          </div>
                          <!-- start single latest news -->
                          <div class="col-md-4">
                              <article class="blog-news-single">
                                  <div class="blog-news-img">
                                      <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-2.jpg" alt="image"></a>
                                  </div>
                                  <div class="blog-news-title">
                                      <h2><a href="blog-single-with-right-sidebar.html">Free Equipment Program</a></h2>
                                      <!--                                      <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>-->
                                  </div>
                                  <!-- <div class="blog-news-details">
                                       <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                       <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                                   </div>-->
                              </article>
                          </div>
                          <!-- start single latest news -->
                          <div class="col-md-4">
                              <article class="blog-news-single">
                                  <div class="blog-news-img">
                                      <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-3.jpg" alt="image"></a>
                                  </div>
                                  <div class="blog-news-title">
                                      <h2><a href="blog-single-with-right-sidebar.html">Already Processing</a></h2>
                                      <!--                                      <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>-->
                                  </div>
                                  <!--  <div class="blog-news-details">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                        <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                                    </div>-->
                              </article>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <!-- End latest news -->
  <!-- End Feature -->

  <!-- Start subscribe us -->
  <?php include_once 'subscribe.php'; ?>
  <!-- End subscribe us -->

  <!-- St art footer -->
  <?php include_once 'footer.php'; ?>
  <!-- End footer -->

  <!-- jQuery library -->
  <?php include_once 'lower_js_loads.php'; ?>

  <!-- Custom js -->
  <script type="text/javascript" src="assets/js/custom.js"></script>
  
  </body>
</html>