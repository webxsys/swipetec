<?php
/**
 * Created by PhpStorm.
 * User: goldenboy
 * Date: 10/2/2016
 * Time: 6:10 PM
 */
?>

<header id="header">
    <!-- header top search -->
    <div class="header-top">
        <div class="container">
            <form action="">
                <div id="search">
                    <input type="text" placeholder="Type your search keyword here and hit Enter..." name="s" id="m_search" style="display: inline-block;">
                    <button type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- header bottom -->
   <div class="header-bottom">
          <div class="container">
          <!-- <div class="row">
                     <div class="col-md-6 col-sm-6 col-xs-6">
                         <div class="header-contact">
                             <ul>
                                 <li>
                                     <div class="phone">
                                         <i class="fa fa-phone"></i>
                                         +1(888)]SWIPE-80
                                     </div>
                                 </li>
                                 <li>
                                     <div class="mail">
                                         <a href="contact.html"  style="color: #e66801;text-decoration: none;">
                                             <i class="fa fa-envelope" style="color: #e66801;" ;></i>
                                             Contact Us
                                         </a>
                                     </div>
                                 </li>
                             </ul>
                         </div>
                     </div>
                     <div class="col-md-6 col-sm-6 col-xs-6">
                         <div class="header-login">
                             <a href="#">FAQ&nbsp;&nbsp;</a>
                             <a class="login modal-form" data-target="#login-form" data-toggle="modal" href="#">Agent Login</a>
                         </div>
                     </div>
                 </div>-->
             </div>
         </div>
</header>
